//------------------------------------------------------------------
// File name:   class_ROBOT101.cpp
// Assign ID:   TERMproject
// Due Date:    12/9/2021      
//
// Purpose:     Base robot class implementation.
//
// Author:      teacherK123 Dr. Jones
//------------------------------------------------------------------
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <cmath>
using namespace std;

#include "class_ROBOT101.h"

// Constructor: default grid is (0,0) to (10,10);
ROBOT101 :: ROBOT101()
{
   xmin = ymin = 0;
   xmax = ymax = 10;
   curX = curY = 0;
   Active = false;
}
