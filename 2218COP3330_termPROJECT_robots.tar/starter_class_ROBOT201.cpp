//------------------------------------------------------------------
// File name:   class_ROBOT201.cpp
// Assign ID:   TERMproject
// Due Date:    12/9/2021      
//
// Purpose:     Base robot class implementation.
//
// Author:      teacherK123 Dr. Jones
//------------------------------------------------------------------
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <cmath>
using namespace std;

#ifndef LOCATION_STRUCT
#define LOCATION_STRUCT
struct LOCATION
{
   float xpos, ypos;
};
#endif

#include "class_ROBOT101.h"
#include "class_ROBOT201.h"

//-----------------------------------------------------------------
// Constructor: use specified grid (MINx, MINy) to (MAXx, MAXy)..
//-----------------------------------------------------------------
ROBOT201 :: ROBOT201( ) : ROBOT101()
{
   inService = false;
   Current.xpos = Current.ypos = 0;
   gridLO.xpos = gridLO.ypos = 0;
   gridHI.xpos = gridHI.ypos = 20;
   Power = 500;
   totDist = 0;
}

